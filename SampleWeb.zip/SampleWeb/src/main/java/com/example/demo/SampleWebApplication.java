package com.example.demo;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.ResponseEntity;

@SpringBootApplication
public class SampleWebApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(SampleWebApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		System.out.println("Inside command line runner of SampleWebApplication with Spring Boot 3.x");
	    ResponseEntity<Object> ok = ResponseEntity.ok().build();
	    System.out.println("Type : " + ok.getStatusCode().getClass());
	    if (ok.getStatusCode().is2xxSuccessful()) {
	      System.out.println("OK");
	    }
	}
}
