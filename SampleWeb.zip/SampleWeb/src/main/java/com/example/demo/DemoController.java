package com.example.demo;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class DemoController {
	
	/*
	@GetMapping("/greet")
	public String greeting() {
		System.out.println(new Timestamp(System.currentTimeMillis()));
		return "Hello current time in UTC is : " + new Timestamp(System.currentTimeMillis());
	}
	
	@PutMapping("/add")
	public void addUser(@RequestBody String user) {
		System.out.println("Inside addUser of user controller.");
	}
	*/
	
	
}
