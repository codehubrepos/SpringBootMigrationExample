package com.study.sample;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.ResponseEntity;

@SpringBootApplication
public class MySimpleWebAppApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(MySimpleWebAppApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		System.out.println("Inside command line runner of SampleWebApplication with Spring Boot 2.x");
	    ResponseEntity<Object> ok = ResponseEntity.ok().build();
	    System.out.println("Type : " + ok.getStatusCode().getClass());
	    boolean statusFlag = ok.getStatusCode().is2xxSuccessful();
	    if(statusFlag) {
	    	System.out.println("OK");
	    }
	}

}
