package com.study.sample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MySimpleWebAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
